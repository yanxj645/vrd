package com;

import cn.tedu.shoot.JmeWorld;

public class Game {
    public static void main(String[] args) {
        JmeWorld.getWorld().start();
    }
}
