package string;

/**
 * int length()
 * 获取当前字符串的长度(字符个数)
 */
public class LengthDemo {
    public static void main(String[] args) {
        String str = "你好java!!";
        System.out.println(str.length());
    }
}
