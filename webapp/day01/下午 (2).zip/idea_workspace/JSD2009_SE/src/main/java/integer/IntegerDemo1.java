package integer;

/**
 * 包装类
 * 包装类在java.lang中作为基础类使用，他们的出现是为了解决基本类型不能直接参与
 * 面向对象开发，让基本类型可以以"对象"的形式存在。
 */
public class IntegerDemo1 {
    public static void main(String[] args) {
        int a = 123;
//        Integer i1 = Integer.valueOf(a);
//        Integer i2 = Integer.valueOf(a);
//        System.out.println(i1 == i2);
//        System.out.println(i1.equals(i2));
//
//
//        int b = i1.intValue();
//        System.out.println(b);
//        double dou = i1.doubleValue();//123.0
//        System.out.println(dou);
    }
}




